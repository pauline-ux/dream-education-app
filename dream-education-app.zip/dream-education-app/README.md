# Dream Education Consulting — Student Portal

## 🚀 Deploy to Vercel in 5 steps

### Step 1 — Create a GitHub account (if you don't have one)
Go to github.com and sign up. It's free.

### Step 2 — Upload this project to GitHub
1. Go to github.com → click the "+" button → "New repository"
2. Name it: `dream-education-app`
3. Click "Create repository"
4. Click "uploading an existing file" and drag this entire folder in
5. Click "Commit changes"

### Step 3 — Deploy on Vercel
1. Go to vercel.com → Sign up with your GitHub account
2. Click "Add New Project"
3. Select `dream-education-app` from your GitHub repos
4. Click "Deploy" — Vercel auto-detects Vite, no settings needed
5. In ~60 seconds you'll have a live URL like: `dream-education-app.vercel.app`

### Step 4 — Connect your domain (app.dreameducationconsulting.com)
1. In Vercel → your project → "Settings" → "Domains"
2. Type: `app.dreameducationconsulting.com` → Add
3. Vercel will show you a CNAME record to add
4. Log into your domain registrar (wherever you bought dreameducationconsulting.com)
5. Add the CNAME record they give you
6. Wait 10–30 minutes — done!

### Step 5 — Add a button on your website
Add this button anywhere on dreameducationconsulting.com:
```
Link: https://app.dreameducationconsulting.com
Text: "Student Portal Login"
```

---

## 🔑 Demo Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Student (Cyrus) | cyrus@email.com | demo123 |
| Student (Sofia) | sofia@email.com | demo123 |
| Counselor (Dr. Markii) | dr.markii@dream.com | dream24 |
| Counselor (Jennifer) | jennifer@dream.com | dream24 |
| Counselor (Dr. Pauline) | pauline@dream.com | dream24 |

---

## ⚠️ Important Notes for Right Now

- **Data does not save yet** — this is a prototype. Each login session starts fresh.
- **To add real students**: edit the `STUDENTS` array and `MOCK_USERS` array in `src/App.jsx`
- **To change passwords**: edit the `MOCK_USERS` array in `src/App.jsx`
- **For real data saving**: you'll need a developer to connect Supabase (database) — budget ~$5K–8K

---

## 📁 File Structure
```
dream-education-app/
├── index.html          ← Entry point
├── package.json        ← Dependencies
├── vite.config.js      ← Build config
├── vercel.json         ← Deployment config
├── public/
│   └── favicon.svg     ← Owl favicon
└── src/
    ├── main.jsx        ← React entry
    └── App.jsx         ← Entire application
```
