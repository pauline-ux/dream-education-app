import { useState, useRef } from "react";

const TEAL = "#005f73";
const GOLD = "#c9a227";
const CREAM = "#fdf6ec";
const LIGHT_GOLD = "#fbe9b0";
const DARK_TEAL = "#003d4d";
const BROWN = "#b5651d";
const PEACH = "#fdebd0";
const RED = "#c0392b";
const GREEN = "#1e8449";

// ─── MOCK USERS (replace with real auth later) ───────────────────────────────
const MOCK_USERS = [
  { email: "cyrus@email.com",    password: "demo123", role: "student",   studentId: 1 },
  { email: "sofia@email.com",    password: "demo123", role: "student",   studentId: 2 },
  { email: "dr.markii@dream.com",password: "dream24",  role: "counselor", name: "Dr. Markii" },
  { email: "jennifer@dream.com", password: "dream24",  role: "counselor", name: "Jennifer" },
  { email: "pauline@dream.com",  password: "dream24",  role: "counselor", name: "Dr. Pauline" },
];

// ─── DATA ────────────────────────────────────────────────────────────────────
const STUDENTS = [
  {
    id: 1, name: "Cyrus Vahabzadeh", grade: "12th", gpa: "3.8", sat: "1480",
    counselor: "Dr. Markii", coach: "Jennifer", avatar: "CV", progress: 68, urgentItems: 2,
    dreamSchool: "Vanderbilt University", targetMajor: "Computer Science & Economics",
    spike: "AI-powered social impact entrepreneurship",
    narrativeTheme: "The Builder — transforms ideas into systems that help others",
    coreValues: ["Innovation", "Community", "Resilience"],
    differentiators: [
      { label: "Founded tech nonprofit at 16", strength: "high", howToUse: "Lead every supplement with a specific impact metric from CodeForChange. '47 students. $12K grant. One kid named Marcus who said I know I can.' That's your hook." },
      { label: "Varsity Tennis Captain + ranked regionally", strength: "high", howToUse: "Use tennis as the metaphor thread in your personal statement. The gap between where the ball is and where it's going = the gap between what exists and what should. Already in Draft 1 — keep it." },
      { label: "Bilingual (English/Farsi)", strength: "medium", howToUse: "Mention this in the 'diversity' framing of Who Am I. It adds a layer to your immigrant-family narrative that most tech applicants don't have." },
      { label: "UM Research Internship + conference abstract", strength: "high", howToUse: "This proves you can operate at a university level. Reference Professor Chen by name. Colleges love specificity. Use in 'Why Major?' supplements." },
    ],
    collegeList: [
      { name: "Vanderbilt",         difficulty: "Reach",  type: "ED1",     deadline: "Nov 1",  status: "In Progress", portalStatus: "Not Submitted", fit: 82 },
      { name: "Boston University",  difficulty: "Reach",  type: "ED2",     deadline: "Jan 1",  status: "Not Started", portalStatus: "Not Submitted", fit: 75 },
      { name: "University of Florida", difficulty: "Target", type: "EA",   deadline: "Nov 1",  status: "Complete",    portalStatus: "Submitted ✓",   fit: 91 },
      { name: "FSU",                difficulty: "Safety", type: "Rolling", deadline: "Nov 15", status: "In Progress", portalStatus: "Not Submitted", fit: 96 },
    ],
    scholarships: [
      { name: "Vanderbilt Ingram Scholarship", amount: "$40,000",   deadline: "Nov 1",        status: "In Progress", requirements: "Separate application + interview" },
      { name: "Bright Futures",               amount: "$3,000/yr", deadline: "Aug 31",        status: "Complete",    requirements: "GPA + community hours" },
      { name: "Big Future (College Board)",   amount: "$500–$40K", deadline: "Monthly lottery", status: "Not Started", requirements: "Complete 7 steps" },
      { name: "Raise.me Micro-Scholarships",  amount: "Varies",    deadline: "Nov 1",         status: "In Progress", requirements: "Fill out profile" },
    ],
    milestones: [
      { label: "Academic review complete",       done: true,  date: "Sep 2024" },
      { label: "Reflection exercises complete",  done: true,  date: "Oct 2024" },
      { label: "College list finalized",         done: true,  date: "Oct 2024" },
      { label: "Letters of rec requested",       done: true,  date: "Sep 2024" },
      { label: "Life Map exercise complete",     done: false, date: "Mar 10" },
      { label: "Personal statement final draft", done: false, date: "Mar 15" },
      { label: "All supplementals complete",     done: false, date: "Apr 1" },
      { label: "Applications submitted",         done: false, date: "Nov 1" },
    ],
    homework: [
      { task: "Complete Life Map exercise",       due: "Mar 10", status: "In Progress",  priority: "high" },
      { task: "Personal Statement Draft 2",       due: "Mar 15", status: "In Progress",  priority: "high" },
      { task: "Vanderbilt supplemental draft 1",  due: "Apr 1",  status: "Did Not Start", priority: "high" },
      { task: "Send brag sheet to teachers",      due: "Mar 20", status: "Did Not Start", priority: "medium" },
      { task: "Create Raise.me account",          due: "Mar 25", status: "Did Not Start", priority: "medium" },
    ],
    checklist: {
      "Academic Review": true, "Reflection": true, "Resume": false, "Linktree": false,
      "Raise.me": false, "Brag Sheets": true, "Letters of Rec": true, "College List": true,
      "Life Map": false, "Personal Statement": false, "Supplementals": false, "Activities": true, "Scholarships": false,
    },
    activities: [
      { type: "Athletics: JV/Varsity", position: "Captain", org: "Varsity Tennis Team", desc: "Led 18-member team to state semifinals; organized 3 charity tournaments raising $4,200 for youth programs.", grades: { 9: false, 10: true, 11: true, 12: true, pg: false }, timing: "All Year", hoursPerWeek: "15", weeksPerYear: "36", current: true, collegeIntent: true },
      { type: "Community Service (Volunteer)", position: "Founder & CEO", org: "CodeForChange", desc: "Founded nonprofit teaching coding to underserved youth; 47 students served; partnered with 3 Miami schools.", grades: { 9: false, 10: false, 11: true, 12: true, pg: false }, timing: "All Year", hoursPerWeek: "10", weeksPerYear: "48", current: true, collegeIntent: true },
      { type: "Research", position: "Research Assistant", org: "University of Miami – Prof. Chen Lab", desc: "Assisted on ML algorithm for early disease detection; co-authored conference abstract.", grades: { 9: false, 10: false, 11: true, 12: false, pg: false }, timing: "School Break", hoursPerWeek: "8", weeksPerYear: "12", current: false, collegeIntent: false },
    ],
    essays: {
      personalStatement: {
        status: "Draft 1", wordCount: 412, maxWords: 650, lastEdited: "Feb 20",
        text: `The tennis ball arced through the humid Miami air at 4:47 AM—the only hour my father could practice before his twelve-hour shift at the hospital. I was six years old, barely tall enough to hold the racket, chasing balls across the cracked community court while he worked on his serve. He'd come to America with $200 and a medical degree that no one here recognized. So he started over.

I think about that image a lot now—not because it's sentimental, but because it taught me something I've spent years trying to articulate: that starting over isn't failure. It's architecture. You survey the terrain, understand what you have, and you build.

At sixteen, I founded CodeForChange because I watched my neighborhood's kids struggle with the same invisible ceiling my father once hit—not lack of talent, but lack of access. So I started building.

What began as weekend workshops in a church basement became something I never anticipated: a community. Forty-seven students. Three school partnerships. A $12,000 grant from the Knight Foundation. And more importantly, a twelve-year-old named Marcus who told me last spring that he wanted to study computer science "because now I know I can."

Tennis taught me that the gap between where the ball is and where it's going is everything. So is the gap between what exists and what should.`,
        comments: [
          { id: 1, author: "Dr. Markii", timestamp: "Feb 21", text: "Cyrus — this opening is STRONG. The 4:47 AM image is visceral and specific. Keep it.", highlight: "4:47 AM", resolved: true },
          { id: 2, author: "Jennifer",   timestamp: "Feb 22", text: "'Starting over isn't failure. It's architecture.' — This is your thesis. The ending must echo this language.", highlight: "starting over isn't failure", resolved: false },
          { id: 3, author: "Dr. Markii", timestamp: "Feb 23", text: "The Marcus detail is perfect. Don't cut it. This is your 'so what' — it humanizes everything.", highlight: "Marcus", resolved: false },
        ]
      },
      supplementals: [
        { school: "Vanderbilt", prompt: "Tell us about a community you've been a part of and what it means to you. (250 words)", status: "Not Started", wordCount: 0, maxWords: 250, text: "", comments: [] },
        { school: "Vanderbilt", prompt: "What drew you to your potential major or area of study? (150 words)", status: "Not Started", wordCount: 0, maxWords: 150, text: "", comments: [] },
        { school: "Boston University", prompt: "What about being a student at BU most excites you? (250 words)", status: "Not Started", wordCount: 0, maxWords: 250, text: "", comments: [] },
      ]
    },
    contactLog: [
      { date: "Feb 20", contact: "Dr. Markii", type: "Video Call", notes: "Reviewed Draft 1. Strong opening. Research paragraph needs depth. Assigned: Draft 2 by Mar 15." },
      { date: "Feb 14", contact: "Jennifer",   type: "Video Call", notes: "Brainstorming session. 'The Builder' narrative emerged. Architecture metaphor is gold — keep it." },
      { date: "Feb 7",  contact: "Dr. Markii", type: "Email",      notes: "Academic review complete. Transcripts sent. Vanderbilt ED1 strategy confirmed. Ingram = high priority." },
    ],
  },
  {
    id: 2, name: "Sofia Ramirez", grade: "11th", gpa: "4.1", sat: "1390",
    counselor: "Dr. Markii", coach: "Jennifer", avatar: "SR", progress: 32, urgentItems: 0,
    dreamSchool: "Georgetown University", targetMajor: "International Relations",
    spike: "Bilingual advocacy & global health equity",
    narrativeTheme: "The Bridge — connects communities across language and culture",
    coreValues: ["Justice", "Empathy", "Voice"],
    differentiators: [
      { label: "Trilingual (English/Spanish/Portuguese)", strength: "high", howToUse: "Lead with this in the diversity supplement. Being trilingual in a global relations program is an operational advantage, not just a personal detail." },
      { label: "Founded school's first Spanish newspaper", strength: "high", howToUse: "This is your proof of initiative. You didn't join a club — you created one where none existed. That's Georgetown material." },
      { label: "Health clinic volunteer (200+ hrs)", strength: "medium", howToUse: "Connect this to your intended major — you understand health equity from the ground up. Use in your 'Why Georgetown' essay." },
    ],
    collegeList: [
      { name: "Georgetown", difficulty: "Reach",  type: "EA", deadline: "Nov 1", status: "Not Started", portalStatus: "Not Submitted", fit: 79 },
      { name: "Tulane",     difficulty: "Target", type: "EA", deadline: "Nov 1", status: "Not Started", portalStatus: "Not Submitted", fit: 85 },
    ],
    scholarships: [
      { name: "QuestBridge", amount: "Full ride", deadline: "Sep 26", status: "Not Started", requirements: "Income-based, highly competitive" },
    ],
    milestones: [
      { label: "Academic review complete",       done: true,  date: "Feb 2025" },
      { label: "Reflection exercises complete",  done: false, date: "Mar 2025" },
      { label: "College list finalized",         done: false, date: "Apr 2025" },
      { label: "Summer program applications",    done: false, date: "Mar 2025" },
    ],
    homework: [
      { task: "Complete reflection questions",      due: "Mar 5",  status: "In Progress",   priority: "high" },
      { task: "Build initial college list",         due: "Mar 15", status: "Did Not Start",  priority: "high" },
      { task: "Apply to Georgetown Summer Institute", due: "Mar 20", status: "Did Not Start", priority: "medium" },
    ],
    checklist: { "Academic Review": true, "Reflection": false, "Resume": false, "College List": false, "Personal Statement": false },
    activities: [
      { type: "Journalism/Publication", position: "Founder & Editor", org: "El Puente Student Newspaper", desc: "Founded school's first Spanish-language newspaper; 12 staff writers; distributed to 3 local community centers.", grades: { 9: false, 10: true, 11: true, 12: false, pg: false }, timing: "School Year", hoursPerWeek: "8", weeksPerYear: "36", current: true, collegeIntent: true },
    ],
    essays: {
      personalStatement: { status: "Not Started", wordCount: 0, maxWords: 650, lastEdited: "—", text: "", comments: [] },
      supplementals: []
    },
    contactLog: [
      { date: "Feb 18", contact: "Dr. Markii", type: "Video Call", notes: "Kickoff session. 'The Bridge' narrative identified. Reflection exercises assigned. Georgetown Summer Institute = must apply." },
    ],
  }
];

// ─── PRIMITIVES ───────────────────────────────────────────────────────────────
const badgeMap = {
  Reach: { bg: "#fde8e8", text: RED }, Target: { bg: "#e8f4fd", text: "#2471a3" }, Safety: { bg: "#e9f7ef", text: GREEN },
  Complete: { bg: "#e9f7ef", text: GREEN }, "In Progress": { bg: "#fef9e7", text: "#b7950b" },
  "Not Started": { bg: "#f2f3f4", text: "#7f8c8d" }, "Did Not Start": { bg: "#f2f3f4", text: "#7f8c8d" },
  high: { bg: "#fde8e8", text: RED }, medium: { bg: "#fef9e7", text: "#b7950b" }, low: { bg: "#e9f7ef", text: GREEN },
};
function Badge({ children }) {
  const c = badgeMap[children] || { bg: LIGHT_GOLD, text: BROWN };
  return <span style={{ background: c.bg, color: c.text, padding: "2px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, whiteSpace: "nowrap", fontFamily: "'DM Sans'" }}>{children}</span>;
}
function PBar({ value, height = 8, color }) {
  return <div style={{ background: "#e8e8e8", borderRadius: 99, height, overflow: "hidden", width: "100%" }}><div style={{ width: `${Math.min(value, 100)}%`, background: color || `linear-gradient(90deg,${TEAL},${GOLD})`, height: "100%", borderRadius: 99, transition: "width .6s" }} /></div>;
}
function Card({ children, style }) { return <div style={{ background: "white", borderRadius: 16, boxShadow: "0 2px 16px rgba(0,95,115,.08)", padding: 24, ...style }}>{children}</div>; }
function H({ children, sm }) { return <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: sm ? 18 : 22, fontWeight: 700, color: DARK_TEAL, marginBottom: sm ? 10 : 18 }}>{children}</div>; }
function TabBar({ tabs, active, onSelect }) {
  return <div style={{ display: "flex", gap: 4, marginBottom: 20, overflowX: "auto", paddingBottom: 4 }}>
    {tabs.map(t => <button key={t.id} onClick={() => onSelect(t.id)} style={{ padding: "10px 14px", borderRadius: 10, border: "none", fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap", background: active === t.id ? TEAL : "white", color: active === t.id ? "white" : "#666", boxShadow: active === t.id ? `0 4px 12px rgba(0,95,115,.3)` : "0 1px 4px rgba(0,0,0,.06)", transition: "all .2s" }}>{t.icon && <span style={{ marginRight: 5 }}>{t.icon}</span>}{t.label}</button>)}
  </div>;
}

// ─── LOGIN SCREEN ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    setError("");
    setLoading(true);
    setTimeout(() => {
      const user = MOCK_USERS.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
      if (user) {
        onLogin(user);
      } else {
        setError("Email or password is incorrect. Please try again.");
      }
      setLoading(false);
    }, 600);
  };

  return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(135deg, ${DARK_TEAL} 0%, ${TEAL} 50%, #007a8c 100%)`, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, overflow: "hidden", pointerEvents: "none" }}>
        <div style={{ position: "absolute", top: -120, right: -120, width: 400, height: 400, borderRadius: "50%", background: "rgba(201,162,39,.08)" }} />
        <div style={{ position: "absolute", bottom: -80, left: -80, width: 300, height: 300, borderRadius: "50%", background: "rgba(201,162,39,.06)" }} />
      </div>

      <div style={{ width: "100%", maxWidth: 420, position: "relative" }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 36 }}>
          <div style={{ width: 64, height: 64, borderRadius: 18, background: GOLD, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, margin: "0 auto 16px" }}>🦉</div>
          <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 28, fontWeight: 700, color: "white", marginBottom: 4 }}>Dream Education</div>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: GOLD, letterSpacing: 4 }}>CONSULTING</div>
        </div>

        {/* Card */}
        <div style={{ background: "white", borderRadius: 20, padding: 36, boxShadow: "0 24px 60px rgba(0,0,0,.25)" }}>
          <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 22, fontWeight: 700, color: DARK_TEAL, marginBottom: 4 }}>Welcome back</div>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#888", marginBottom: 28 }}>Sign in to your student portal</div>

          <div style={{ marginBottom: 16 }}>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>EMAIL ADDRESS</div>
            <input
              type="email" value={email} onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleLogin()}
              placeholder="your@email.com"
              style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `1.5px solid ${error ? RED : "#e0d8cc"}`, fontFamily: "'DM Sans'", fontSize: 15, outline: "none", transition: "border .2s" }}
              onFocus={e => e.target.style.borderColor = TEAL}
              onBlur={e => e.target.style.borderColor = error ? RED : "#e0d8cc"}
            />
          </div>

          <div style={{ marginBottom: 8 }}>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>PASSWORD</div>
            <input
              type="password" value={password} onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleLogin()}
              placeholder="••••••••"
              style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `1.5px solid ${error ? RED : "#e0d8cc"}`, fontFamily: "'DM Sans'", fontSize: 15, outline: "none", transition: "border .2s" }}
              onFocus={e => e.target.style.borderColor = TEAL}
              onBlur={e => e.target.style.borderColor = error ? RED : "#e0d8cc"}
            />
          </div>

          <div style={{ textAlign: "right", marginBottom: 20 }}>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 13, color: TEAL, cursor: "pointer", fontWeight: 500 }}>Forgot password?</span>
          </div>

          {error && <div style={{ padding: "10px 14px", background: "#fde8e8", borderRadius: 10, fontFamily: "'DM Sans'", fontSize: 13, color: RED, marginBottom: 16 }}>⚠️ {error}</div>}

          <button
            onClick={handleLogin}
            disabled={loading || !email || !password}
            style={{ width: "100%", padding: "14px", background: loading || !email || !password ? "#ccc" : `linear-gradient(135deg,${TEAL},${DARK_TEAL})`, color: "white", border: "none", borderRadius: 12, fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 16, cursor: loading || !email || !password ? "default" : "pointer", boxShadow: "0 4px 16px rgba(0,95,115,.3)", transition: "all .2s" }}
          >
            {loading ? "Signing in…" : "Sign In →"}
          </button>

          <div style={{ marginTop: 24, padding: "14px 16px", background: PEACH, borderRadius: 12, border: `1px solid ${LIGHT_GOLD}` }}>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>🔑 Demo Accounts</div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#555", lineHeight: 1.8 }}>
              Student: <strong>cyrus@email.com</strong> / demo123<br />
              Counselor: <strong>dr.markii@dream.com</strong> / dream24
            </div>
          </div>
        </div>

        <div style={{ textAlign: "center", marginTop: 20, fontFamily: "'DM Sans'", fontSize: 13, color: "rgba(255,255,255,.6)" }}>
          Dream Big. Plan Smart. Beat the Odds.
        </div>
      </div>
    </div>
  );
}

// ─── LIFE MAP ─────────────────────────────────────────────────────────────────
const LIFE_MAP_STEPS = [
  { id: "intro", title: "Welcome to Your Life Map", icon: "🗺", desc: "This guided journey takes 30–45 minutes. You'll explore the moments, people, values, and dreams that make you who you are. There are no right answers — only your truth.", type: "intro" },
  { id: "timeline", title: "Timeline of Growth", icon: "📅", desc: "Think about key moments — big AND small. Moments when you were one way before something happened, and somehow different after.", type: "forked", prompts: ["A moment when you surprised yourself", "A failure that taught you something", "A time you stood up for something", "The moment you discovered something you loved"] },
  { id: "values", title: "Your Core Values", icon: "💎", desc: "Values are the invisible compass guiding every decision. List up to 7 that truly feel like YOU — not what sounds impressive.", type: "values", options: ["Creativity", "Justice", "Family", "Excellence", "Curiosity", "Adventure", "Service", "Resilience", "Integrity", "Freedom", "Connection", "Growth", "Courage", "Empathy", "Innovation", "Authenticity", "Leadership", "Wisdom"] },
  { id: "identities", title: "My Identities", icon: "🪞", desc: "We all carry multiple identities. Some visible, some hidden. Which parts of who you are feel most essential?", type: "prompts", prompts: ["An identity you're proud of but rarely talk about", "An identity others always notice first", "An identity that surprises people", "An identity that gives you strength"] },
  { id: "homes", title: "My Homes", icon: "🏠", desc: "Home isn't just a place. It can be a language, a sport, a kitchen, a grandparent's house, a team. Where do you feel most yourself?", type: "prompts", prompts: ["A physical place", "A community or group", "A creative outlet or ritual", "A relationship"] },
  { id: "careers", title: "Dream Futures", icon: "🚀", desc: "Forget what's realistic for a moment. If you could wake up in 15 years doing anything — what would it be?", type: "prompts", prompts: ["The problem in the world you most want to solve", "What success looks like to you (not your parents)", "A career that would terrify and excite you equally", "The legacy you want to leave"] },
  { id: "complete", title: "Your Life Map is Complete", icon: "✨", desc: "You've done something most adults never do — you've paused to truly examine who you are. Dr. Markii will review your responses before your next session.", type: "complete" },
];

function LifeMapTab() {
  const [step, setStep] = useState(0);
  const [responses, setResponses] = useState({});
  const [selectedValues, setSelectedValues] = useState([]);
  const [forked, setForked] = useState([{ before: "", moment: "", after: "" }]);
  const current = LIFE_MAP_STEPS[step];
  const progress = (step / (LIFE_MAP_STEPS.length - 1)) * 100;
  const upd = (key, val) => setResponses(p => ({ ...p, [key]: val }));
  const toggleV = v => setSelectedValues(p => p.includes(v) ? p.filter(x => x !== v) : p.length < 7 ? [...p, v] : p);

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL, fontSize: 14 }}>Step {step + 1} of {LIFE_MAP_STEPS.length}</span>
          <span style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "#888" }}>{Math.round(progress)}%</span>
        </div>
        <PBar value={progress} height={8} />
      </div>

      <Card style={{ marginBottom: 20 }}>
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>{current.icon}</div>
          <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 26, fontWeight: 700, color: DARK_TEAL, marginBottom: 10 }}>{current.title}</div>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 15, color: "#555", lineHeight: 1.7, maxWidth: 560, margin: "0 auto" }}>{current.desc}</div>
        </div>

        {current.type === "intro" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, maxWidth: 480, margin: "0 auto" }}>
            {[["📅", "Timeline"], ["💎", "Values"], ["🪞", "Identities"], ["🏠", "Homes"], ["🚀", "Dream Futures"], ["✨", "Complete"]].map(([ic, lb]) => (
              <div key={lb} style={{ padding: "14px 10px", background: PEACH, borderRadius: 12, textAlign: "center" }}>
                <div style={{ fontSize: 24, marginBottom: 6 }}>{ic}</div>
                <div style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: DARK_TEAL }}>{lb}</div>
              </div>
            ))}
          </div>
        )}

        {current.type === "forked" && (
          <div>
            {forked.map((entry, i) => (
              <div key={i} style={{ marginBottom: 20, padding: 18, background: PEACH, borderRadius: 14, border: `1px solid ${LIGHT_GOLD}` }}>
                <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 16, fontWeight: 700, color: DARK_TEAL, marginBottom: 12 }}>Moment {i + 1}</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                  {[["Before, I was…", "before"], ["The moment / event", "moment"], ["After, I became…", "after"]].map(([label, key]) => (
                    <div key={key}>
                      <div style={{ fontFamily: "'DM Sans'", fontSize: 11, fontWeight: 600, color: BROWN, marginBottom: 6 }}>{label}</div>
                      <textarea value={entry[key]} onChange={e => setForked(p => p.map((x, j) => j === i ? { ...x, [key]: e.target.value } : x))} rows={4} placeholder="Write freely…" style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, resize: "none", outline: "none" }} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
            <div style={{ marginBottom: 12 }}>
              <button onClick={() => setForked(p => [...p, { before: "", moment: "", after: "" }])} style={{ padding: "8px 18px", background: "white", border: `2px solid ${TEAL}`, borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL, cursor: "pointer" }}>+ Add Another Moment</button>
            </div>
            <div style={{ padding: "12px 16px", background: LIGHT_GOLD, borderRadius: 10 }}>
              <div style={{ fontFamily: "'DM Sans'", fontSize: 13, color: BROWN }}>💡 Try these: {current.prompts.join(" · ")}</div>
            </div>
          </div>
        )}

        {current.type === "values" && (
          <div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "#888", marginBottom: 16, textAlign: "center" }}>Select up to 7 ({selectedValues.length}/7)</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "center", marginBottom: 20 }}>
              {current.options.map(v => (
                <button key={v} onClick={() => toggleV(v)} style={{ padding: "10px 18px", borderRadius: 20, border: `2px solid ${selectedValues.includes(v) ? TEAL : "#ddd"}`, background: selectedValues.includes(v) ? TEAL : "white", color: selectedValues.includes(v) ? "white" : "#555", fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 14, cursor: "pointer", transition: "all .2s" }}>
                  {selectedValues.includes(v) && "✓ "}{v}
                </button>
              ))}
            </div>
            {selectedValues.length > 0 && selectedValues.map(v => (
              <div key={v} style={{ marginBottom: 10, display: "flex", gap: 12, alignItems: "flex-start" }}>
                <div style={{ padding: "6px 14px", background: TEAL, color: "white", borderRadius: 20, fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, whiteSpace: "nowrap" }}>{v}</div>
                <textarea value={responses[`val_${v}`] || ""} onChange={e => upd(`val_${v}`, e.target.value)} rows={2} placeholder={`What does ${v} look like in your actual life?`} style={{ flex: 1, padding: 10, borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, resize: "none", outline: "none" }} />
              </div>
            ))}
          </div>
        )}

        {current.type === "prompts" && (
          <div style={{ display: "grid", gap: 14 }}>
            {current.prompts.map((prompt, i) => (
              <div key={i} style={{ padding: 16, background: PEACH, borderRadius: 14, border: `1px solid ${LIGHT_GOLD}` }}>
                <div style={{ fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 600, color: BROWN, marginBottom: 8 }}>{prompt}</div>
                <textarea value={responses[`${current.id}_${i}`] || ""} onChange={e => upd(`${current.id}_${i}`, e.target.value)} rows={3} placeholder="Write freely — no one is grading this. Just be honest." style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, resize: "none", outline: "none" }} />
              </div>
            ))}
          </div>
        )}

        {current.type === "complete" && (
          <div style={{ textAlign: "center" }}>
            <div style={{ display: "inline-flex", flexDirection: "column", gap: 10, alignItems: "flex-start", background: PEACH, borderRadius: 16, padding: 24, marginBottom: 20 }}>
              {["Timeline of Growth ✓", "Core Values ✓", "My Identities ✓", "My Homes ✓", "Dream Futures ✓"].map(item => (
                <div key={item} style={{ fontFamily: "'DM Sans'", fontWeight: 600, color: GREEN, fontSize: 15, display: "flex", gap: 10, alignItems: "center" }}>
                  <span style={{ width: 26, height: 26, borderRadius: "50%", background: GREEN, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: 13, flexShrink: 0 }}>✓</span>{item}
                </div>
              ))}
            </div>
            <div style={{ padding: "14px 20px", background: LIGHT_GOLD, borderRadius: 12, maxWidth: 500, margin: "0 auto", fontFamily: "'DM Sans'", fontSize: 14, color: BROWN, lineHeight: 1.6 }}>
              <strong>Dr. Markii will review your Life Map before your next session.</strong> This is the raw material of your entire application.
            </div>
          </div>
        )}
      </Card>

      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <button onClick={() => setStep(p => Math.max(0, p - 1))} disabled={step === 0} style={{ padding: "12px 28px", background: step === 0 ? "#f0f0f0" : "white", border: `2px solid ${step === 0 ? "#ddd" : TEAL}`, borderRadius: 12, fontFamily: "'DM Sans'", fontWeight: 600, color: step === 0 ? "#bbb" : TEAL, cursor: step === 0 ? "default" : "pointer" }}>← Previous</button>
        {step < LIFE_MAP_STEPS.length - 1
          ? <button onClick={() => setStep(p => p + 1)} style={{ padding: "12px 28px", background: `linear-gradient(135deg,${TEAL},${DARK_TEAL})`, border: "none", borderRadius: 12, fontFamily: "'DM Sans'", fontWeight: 600, color: "white", cursor: "pointer" }}>{step === 0 ? "Begin My Life Map →" : "Next Step →"}</button>
          : <button style={{ padding: "12px 28px", background: `linear-gradient(135deg,${GREEN},#145a32)`, border: "none", borderRadius: 12, fontFamily: "'DM Sans'", fontWeight: 600, color: "white", cursor: "pointer" }}>Submit to Counselor ✓</button>
        }
      </div>
    </div>
  );
}

// ─── VISION BOARD ─────────────────────────────────────────────────────────────
const VB_CATS = [
  { id: "schools",   label: "Dream Schools",      icon: "🏛", color: "#e8f4fd", items: ["Vanderbilt", "Georgetown", "Stanford", "MIT", "Oxford"] },
  { id: "careers",   label: "Future Careers",     icon: "🚀", color: "#e9f7ef", items: ["Entrepreneur", "Researcher", "Policy Maker", "Tech CEO", "Professor"] },
  { id: "values",    label: "What I Stand For",   icon: "💎", color: PEACH,     items: ["Innovation", "Justice", "Community", "Excellence", "Courage"] },
  { id: "lifestyle", label: "The Life I Want",    icon: "🌍", color: "#fdf2ff", items: ["Travel the world", "Build a company", "Write a book", "Give back"] },
  { id: "words",     label: "Words That Define Me", icon: "✦", color: LIGHT_GOLD, items: ["Builder", "Bridge", "Changemaker", "Curious", "Resilient"] },
  { id: "custom",    label: "My Own Dreams",      icon: "⭐", color: "#f0fff4",  items: [] },
];

function VisionBoardTab() {
  const [board, setBoard] = useState({});
  const [custom, setCustom] = useState([]);
  const [input, setInput] = useState("");
  const [quote, setQuote] = useState("Dream Big. Plan Smart. Beat the Odds.");
  const toggle = (cid, item) => setBoard(p => ({ ...p, [`${cid}_${item}`]: !p[`${cid}_${item}`] }));
  const isOn = (cid, item) => !!board[`${cid}_${item}`];
  const total = Object.values(board).filter(Boolean).length + custom.length;

  return (
    <div>
      <div style={{ background: `linear-gradient(135deg,${DARK_TEAL},${TEAL})`, borderRadius: 16, padding: 24, marginBottom: 20, color: "white", textAlign: "center" }}>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 11, letterSpacing: 3, color: GOLD, marginBottom: 8 }}>YOUR VISION BOARD</div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 26, fontWeight: 700, marginBottom: 10 }}>"{quote}"</div>
        <input value={quote} onChange={e => setQuote(e.target.value)} style={{ background: "rgba(255,255,255,.1)", border: "1px solid rgba(255,255,255,.3)", borderRadius: 8, padding: "6px 14px", color: "white", fontFamily: "'DM Sans'", fontSize: 13, textAlign: "center", width: "100%", maxWidth: 400, outline: "none" }} placeholder="Edit your personal motto…" />
        <div style={{ marginTop: 10, fontFamily: "'DM Sans'", fontSize: 13, color: "rgba(255,255,255,.6)" }}>{total} items on your board</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
        {VB_CATS.map(cat => (
          <div key={cat.id} style={{ background: cat.color, borderRadius: 16, padding: 18, border: "1px solid rgba(0,0,0,.06)" }}>
            <div style={{ fontFamily: "'DM Sans'", fontWeight: 700, color: DARK_TEAL, marginBottom: 12, display: "flex", gap: 8, alignItems: "center" }}><span style={{ fontSize: 20 }}>{cat.icon}</span> {cat.label}</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {cat.items.map(item => (
                <button key={item} onClick={() => toggle(cat.id, item)} style={{ padding: "8px 14px", borderRadius: 20, border: `2px solid ${isOn(cat.id, item) ? TEAL : "rgba(0,0,0,.12)"}`, background: isOn(cat.id, item) ? TEAL : "white", color: isOn(cat.id, item) ? "white" : "#555", fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, cursor: "pointer", transition: "all .2s" }}>
                  {isOn(cat.id, item) ? "✓ " : ""}{item}
                </button>
              ))}
              {cat.id === "custom" && (
                <div style={{ display: "flex", gap: 8, width: "100%", marginTop: 4 }}>
                  <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && input.trim()) { setCustom(p => [...p, input.trim()]); setInput(""); } }} placeholder="Add your own dream…" style={{ flex: 1, padding: "8px 12px", borderRadius: 20, border: "2px solid #ddd", fontFamily: "'DM Sans'", fontSize: 13, outline: "none" }} />
                  <button onClick={() => { if (input.trim()) { setCustom(p => [...p, input.trim()]); setInput(""); } }} style={{ padding: "8px 14px", background: TEAL, color: "white", border: "none", borderRadius: 20, fontFamily: "'DM Sans'", fontWeight: 600, cursor: "pointer" }}>+</button>
                </div>
              )}
              {cat.id === "custom" && custom.map(item => <button key={item} style={{ padding: "8px 14px", borderRadius: 20, border: `2px solid ${GOLD}`, background: GOLD, color: "white", fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, cursor: "default" }}>⭐ {item}</button>)}
            </div>
          </div>
        ))}
      </div>

      {total > 0 && (
        <Card>
          <H sm>Your Vision Board</H>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
            {VB_CATS.map(cat => cat.items.filter(item => isOn(cat.id, item)).map(item => (
              <div key={`${cat.id}_${item}`} style={{ padding: "10px 18px", borderRadius: 12, background: cat.color, border: `2px solid ${TEAL}`, fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 14, color: DARK_TEAL, display: "flex", gap: 8, alignItems: "center" }}><span>{cat.icon}</span> {item}</div>
            )))}
            {custom.map(item => <div key={item} style={{ padding: "10px 18px", borderRadius: 12, background: LIGHT_GOLD, border: `2px solid ${GOLD}`, fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 14, color: DARK_TEAL }}>⭐ {item}</div>)}
          </div>
        </Card>
      )}
    </div>
  );
}

// ─── BEAT THE ODDS ────────────────────────────────────────────────────────────
function BeatTheOddsTab({ student }) {
  const [expanded, setExpanded] = useState(null);
  const sc = { high: { bg: "#e9f7ef", border: GREEN, icon: "🌟", label: "Elite Differentiator" }, medium: { bg: "#fef9e7", border: "#b7950b", icon: "⚡", label: "Strong Asset" }, low: { bg: PEACH, border: BROWN, icon: "📌", label: "Supporting Detail" } };
  return (
    <div>
      <div style={{ background: `linear-gradient(135deg,${DARK_TEAL},${TEAL})`, borderRadius: 16, padding: 24, marginBottom: 20, color: "white" }}>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 11, letterSpacing: 3, color: GOLD, marginBottom: 8 }}>BEAT THE ODDS</div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 26, fontWeight: 700, marginBottom: 8 }}>Your Unfair Advantages</div>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "rgba(255,255,255,.75)", lineHeight: 1.6 }}>Every applicant has a GPA and test scores. These are the things only <em>you</em> bring. Click each one to learn how to activate it.</div>
      </div>
      <Card style={{ marginBottom: 20, background: PEACH, boxShadow: "none", border: `1px solid ${LIGHT_GOLD}` }}>
        <H sm>What an AO Sees in 8 Minutes</H>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {[["Academic profile", `GPA ${student.gpa} / SAT ${student.sat}`, true], ["Spike clarity", "Tech + Community = rare combo", true], ["Narrative thread", "Emerging — needs essay polish", false], ["Wow factor", "Founded nonprofit at 16", true]].map(([l, v, g]) => (
            <div key={l} style={{ padding: "12px 14px", borderRadius: 12, background: "white", border: `1px solid ${g ? GREEN + "40" : "#ddd"}` }}>
              <div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "#999", marginBottom: 4 }}>{l.toUpperCase()}</div>
              <div style={{ fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 14, color: g ? GREEN : BROWN }}>{g ? "✓ " : ""}{v}</div>
            </div>
          ))}
        </div>
      </Card>
      <H sm>Click to Activate Each Differentiator</H>
      {student.differentiators.map((d, i) => {
        const s = sc[d.strength];
        const open = expanded === i;
        return (
          <div key={i} onClick={() => setExpanded(open ? null : i)} style={{ marginBottom: 12, borderRadius: 14, border: `2px solid ${open ? s.border : "#e8e0d0"}`, background: open ? s.bg : "white", cursor: "pointer", overflow: "hidden", transition: "all .25s" }}>
            <div style={{ padding: "16px 20px", display: "flex", gap: 14, alignItems: "center" }}>
              <span style={{ fontSize: 24 }}>{s.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "'DM Sans'", fontWeight: 700, color: DARK_TEAL, fontSize: 15 }}>{d.label}</div>
                <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#888", marginTop: 2 }}>{s.label}</div>
              </div>
              <div style={{ fontFamily: "'DM Sans'", fontSize: 18, color: s.border, transition: "transform .25s", transform: open ? "rotate(90deg)" : "none" }}>›</div>
            </div>
            {open && (
              <div style={{ padding: "0 20px 20px" }}>
                <div style={{ height: 1, background: s.border + "30", marginBottom: 14 }} />
                <div style={{ fontFamily: "'DM Sans'", fontSize: 11, letterSpacing: 2, color: s.border, marginBottom: 8 }}>HOW TO ACTIVATE THIS</div>
                <div style={{ fontFamily: "'DM Sans'", fontSize: 15, color: "#333", lineHeight: 1.7, padding: "14px 16px", background: "white", borderRadius: 10, border: `1px solid ${s.border}40` }}>{d.howToUse}</div>
              </div>
            )}
          </div>
        );
      })}
      <Card style={{ marginTop: 16, border: `2px solid ${GOLD}`, boxShadow: "none" }}>
        <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
          <span style={{ fontSize: 28 }}>🦉</span>
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 18, fontWeight: 700, color: DARK_TEAL, marginBottom: 8 }}>Dr. Markii's Strategic Brief</div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#444", lineHeight: 1.75 }}>You don't need to be perfect to get in. You need to be <strong>irreplaceable</strong>. The stats get you considered. The story gets you in.</div>
          </div>
        </div>
      </Card>
    </div>
  );
}

// ─── CHECKLIST ────────────────────────────────────────────────────────────────
function ChecklistTab({ student }) {
  const [items, setItems] = useState(student.checklist);
  const done = Object.values(items).filter(Boolean).length;
  const total = Object.keys(items).length;
  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}><span style={{ fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL }}>{done}/{total} complete</span><span style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#888" }}>{Math.round(done / total * 100)}%</span></div>
        <PBar value={done / total * 100} height={10} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {Object.entries(items).map(([key, val]) => (
          <div key={key} onClick={() => setItems(p => ({ ...p, [key]: !p[key] }))} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderRadius: 12, background: val ? "#e9f7ef" : PEACH, cursor: "pointer", border: `1.5px solid ${val ? GREEN : "transparent"}`, transition: "all .2s" }}>
            <div style={{ width: 22, height: 22, borderRadius: 6, background: val ? GREEN : "white", border: `2px solid ${val ? GREEN : "#ccc"}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{val && <span style={{ color: "white", fontSize: 13 }}>✓</span>}</div>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 14, fontWeight: val ? 600 : 400, color: val ? GREEN : "#444" }}>{key}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── HOMEWORK ─────────────────────────────────────────────────────────────────
function HomeworkTab({ student }) {
  const [tasks, setTasks] = useState(student.homework);
  const [nt, setNt] = useState(""); const [nd, setNd] = useState("");
  const opts = ["Did Not Start", "In Progress", "Complete", "Need to Ask"];
  const add = () => { if (!nt) return; setTasks(p => [...p, { task: nt, due: nd || "TBD", status: "Did Not Start", priority: "medium" }]); setNt(""); setNd(""); };
  const sorted = [...tasks].sort((a, b) => ({ high: 0, medium: 1, low: 2 }[a.priority] - { high: 0, medium: 1, low: 2 }[b.priority]));
  return (
    <div>
      <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <input value={nt} onChange={e => setNt(e.target.value)} placeholder="Add a task…" style={{ flex: 1, padding: "10px 14px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} />
        <input value={nd} onChange={e => setNd(e.target.value)} placeholder="Due date" style={{ width: 130, padding: "10px 14px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} />
        <button onClick={add} style={{ padding: "10px 18px", background: TEAL, color: "white", border: "none", borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, cursor: "pointer" }}>+ Add</button>
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead><tr style={{ borderBottom: `2px solid ${LIGHT_GOLD}` }}>{["Priority", "Task", "Due", "Status"].map(h => <th key={h} style={{ textAlign: "left", padding: "8px 12px", fontFamily: "'DM Sans'", fontSize: 13, color: BROWN, fontWeight: 600 }}>{h}</th>)}</tr></thead>
        <tbody>{sorted.map((t, i) => <tr key={i} style={{ borderBottom: "1px solid #f0e6d3" }}>
          <td style={{ padding: "12px" }}><Badge>{t.priority}</Badge></td>
          <td style={{ padding: "12px", fontFamily: "'DM Sans'", fontSize: 14, color: t.status === "Complete" ? "#aaa" : "#333", textDecoration: t.status === "Complete" ? "line-through" : "none" }}>{t.task}</td>
          <td style={{ padding: "12px", fontFamily: "'DM Sans'", fontSize: 14, color: "#666" }}>{t.due}</td>
          <td style={{ padding: "12px" }}><select value={t.status} onChange={e => setTasks(p => p.map((x, j) => j === i ? { ...x, status: e.target.value } : x))} style={{ padding: "4px 8px", borderRadius: 8, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 13, background: "white" }}>{opts.map(s => <option key={s}>{s}</option>)}</select></td>
        </tr>)}</tbody>
      </table>
    </div>
  );
}

// ─── COLLEGE LIST ─────────────────────────────────────────────────────────────
function CollegeListTab({ student }) {
  return (
    <div>
      <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 16 }}>
        <thead><tr style={{ background: BROWN }}>{["College", "Fit", "Difficulty", "Type", "Deadline", "Status"].map(h => <th key={h} style={{ textAlign: "left", padding: "10px 12px", fontFamily: "'DM Sans'", fontSize: 12, color: "white", fontWeight: 600 }}>{h}</th>)}</tr></thead>
        <tbody>{student.collegeList.map((c, i) => <tr key={i} style={{ background: i % 2 === 0 ? PEACH : "white", borderBottom: "1px solid #f0e6d3" }}>
          <td style={{ padding: "12px", fontFamily: "'DM Sans'", fontWeight: 700, color: DARK_TEAL }}>{c.name}</td>
          <td style={{ padding: "12px", minWidth: 90 }}><div style={{ display: "flex", alignItems: "center", gap: 6 }}><PBar value={c.fit} height={5} color={c.fit > 85 ? GREEN : c.fit > 70 ? TEAL : GOLD} /><span style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 700, color: TEAL, minWidth: 30 }}>{c.fit}%</span></div></td>
          <td style={{ padding: "12px" }}><Badge>{c.difficulty}</Badge></td>
          <td style={{ padding: "12px", fontFamily: "'DM Sans'", fontSize: 13 }}>{c.type}</td>
          <td style={{ padding: "12px", fontFamily: "'DM Sans'", fontSize: 13, color: "#666" }}>{c.deadline}</td>
          <td style={{ padding: "12px" }}><Badge>{c.status}</Badge></td>
        </tr>)}</tbody>
      </table>
      <button style={{ padding: "10px 20px", background: "white", border: `2px solid ${TEAL}`, borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL, cursor: "pointer" }}>+ Add College</button>
    </div>
  );
}

// ─── ESSAY EDITOR ─────────────────────────────────────────────────────────────
function EssayEditor({ essay, title, isStudent }) {
  const [text, setText] = useState(essay.text || "");
  const [comments, setComments] = useState(essay.comments || []);
  const [nc, setNc] = useState(""); const [showAdd, setShowAdd] = useState(false); const [sel, setSel] = useState("");
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const max = essay.maxWords || 650; const pct = Math.min((words / max) * 100, 100); const over = words > max;
  const addC = () => { if (!nc.trim()) return; setComments(p => [...p, { id: Date.now(), author: isStudent ? "Student" : "Dr. Markii", timestamp: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" }), text: nc, highlight: sel, resolved: false }]); setNc(""); setShowAdd(false); setSel(""); };
  const handleSel = () => { const s = window.getSelection().toString().trim(); if (s.length > 8 && s.length < 200) setSel(s); };
  const open = comments.filter(c => !c.resolved); const res = comments.filter(c => c.resolved);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20, alignItems: "start" }}>
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 20, fontWeight: 700, color: DARK_TEAL }}>{title}</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 600, color: over ? RED : pct > 85 ? BROWN : TEAL }}>{words}/{max} words</span>
            {!isStudent && <button onClick={() => { setShowAdd(true); if (!sel) setSel("(General)"); }} style={{ padding: "6px 14px", background: GOLD, color: "white", border: "none", borderRadius: 8, fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 12, cursor: "pointer" }}>+ Comment</button>}
          </div>
        </div>
        <PBar value={pct} height={5} color={over ? RED : pct > 85 ? BROWN : undefined} />
        <textarea value={text} onChange={e => setText(e.target.value)} onMouseUp={handleSel} onKeyUp={handleSel} readOnly={!isStudent} placeholder={isStudent ? "Start writing here. This is your story." : "Student hasn't written yet."} rows={22} style={{ width: "100%", padding: 20, marginTop: 10, borderRadius: 14, border: "2px solid #e0d8cc", fontFamily: "'DM Sans'", fontSize: 15, lineHeight: 1.85, resize: "vertical", outline: "none", background: isStudent ? "white" : "#fafaf8", color: "#2c2c2c" }} />
        {sel && !isStudent && <div style={{ marginTop: 8, padding: "10px 14px", background: LIGHT_GOLD, borderRadius: 10, fontFamily: "'DM Sans'", fontSize: 13, color: BROWN, display: "flex", gap: 12, alignItems: "center" }}><span>"{sel.slice(0, 50)}…"</span><button onClick={() => setShowAdd(true)} style={{ padding: "4px 12px", background: TEAL, color: "white", border: "none", borderRadius: 6, fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 12, cursor: "pointer" }}>Comment</button></div>}
        {showAdd && <div style={{ marginTop: 12, padding: 16, background: PEACH, borderRadius: 12, border: `1px solid ${LIGHT_GOLD}` }}><textarea value={nc} onChange={e => setNc(e.target.value)} placeholder="Leave feedback…" rows={3} style={{ width: "100%", padding: 12, borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none", resize: "none" }} /><div style={{ display: "flex", gap: 8, marginTop: 8 }}><button onClick={addC} style={{ padding: "8px 18px", background: TEAL, color: "white", border: "none", borderRadius: 8, fontFamily: "'DM Sans'", fontWeight: 600, cursor: "pointer" }}>Post</button><button onClick={() => { setShowAdd(false); setSel(""); }} style={{ padding: "8px 18px", background: "white", border: "1px solid #ddd", borderRadius: 8, fontFamily: "'DM Sans'", cursor: "pointer" }}>Cancel</button></div></div>}
      </div>
      <div>
        <div style={{ fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL, marginBottom: 12, fontSize: 14 }}>💬 Feedback ({open.length} open)</div>
        {comments.length === 0 && <div style={{ padding: 24, background: "#f8f8f8", borderRadius: 12, textAlign: "center", fontFamily: "'DM Sans'", fontSize: 14, color: "#bbb" }}>{isStudent ? "Your counselor's feedback will appear here." : "Select text to comment."}</div>}
        {open.map(c => <div key={c.id} style={{ marginBottom: 12, padding: 14, background: "white", borderRadius: 12, border: `2px solid ${c.author === "Dr. Markii" ? TEAL : GOLD}`, boxShadow: "0 2px 8px rgba(0,0,0,.05)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><div style={{ fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 13, color: c.author === "Dr. Markii" ? TEAL : BROWN }}>{c.author}</div><div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "#aaa" }}>{c.timestamp}</div></div>
          {c.highlight && c.highlight !== "(General)" && <div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "#888", background: LIGHT_GOLD, padding: "4px 8px", borderRadius: 6, marginBottom: 8, fontStyle: "italic" }}>"{c.highlight.slice(0, 55)}"</div>}
          <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#444", lineHeight: 1.5 }}>{c.text}</div>
          <button onClick={() => setComments(p => p.map(x => x.id === c.id ? { ...x, resolved: true } : x))} style={{ marginTop: 8, padding: "3px 12px", background: "transparent", border: "1px solid #ddd", borderRadius: 6, fontFamily: "'DM Sans'", fontSize: 12, cursor: "pointer", color: "#888" }}>✓ Resolve</button>
        </div>)}
        {res.length > 0 && <div style={{ marginTop: 8 }}><div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "#bbb", marginBottom: 6 }}>RESOLVED ({res.length})</div>{res.map(c => <div key={c.id} style={{ marginBottom: 6, padding: 10, background: "#f8f8f8", borderRadius: 10, opacity: .65 }}><div style={{ fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 11, color: "#aaa" }}>{c.author} · ✓</div><div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#bbb", marginTop: 3 }}>{c.text}</div></div>)}</div>}
      </div>
    </div>
  );
}

function EssaysTab({ student, isStudent }) {
  const [ae, setAe] = useState("ps");
  const ps = student.essays.personalStatement;
  const sups = student.essays.supplementals || [];
  const phases = [{ icon: "💭", label: "Brainstorm", done: true }, { icon: "✍️", label: "Draft & Craft", done: ps.wordCount > 0 }, { icon: "🏛️", label: "Supplementals", done: false }, { icon: "✨", label: "Polish", done: false }];
  const btns = [{ id: "ps", label: "Personal Statement" }, ...sups.map((s, i) => ({ id: `s${i}`, label: `${s.school} #${i + 1}` }))];
  return (
    <div>
      <div style={{ display: "flex", gap: 0, marginBottom: 24, borderRadius: 12, overflow: "hidden", border: `1px solid ${LIGHT_GOLD}` }}>
        {phases.map((p, i) => <div key={i} style={{ flex: 1, padding: "14px 10px", background: p.done ? TEAL : "#f5f0e8", textAlign: "center", borderRight: i < 3 ? "1px solid rgba(255,255,255,.2)" : "none" }}><div style={{ fontSize: 20, marginBottom: 4 }}>{p.icon}</div><div style={{ fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 11, color: p.done ? "white" : "#999" }}>Phase {i + 1}</div><div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: p.done ? "rgba(255,255,255,.8)" : "#bbb" }}>{p.label}</div></div>)}
      </div>
      <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {btns.map(t => <button key={t.id} onClick={() => setAe(t.id)} style={{ padding: "8px 16px", borderRadius: 10, border: "none", fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, cursor: "pointer", background: ae === t.id ? TEAL : "white", color: ae === t.id ? "white" : "#666", boxShadow: "0 1px 4px rgba(0,0,0,.07)" }}>{t.label}</button>)}
      </div>
      {ae === "ps" && <EssayEditor essay={ps} title="Personal Statement" isStudent={isStudent} />}
      {sups.map((s, i) => ae === `s${i}` && <div key={i}><div style={{ padding: "12px 16px", background: PEACH, borderRadius: 12, marginBottom: 16, fontFamily: "'DM Sans'", fontSize: 14, color: "#555", border: `1px solid ${LIGHT_GOLD}` }}><strong>Prompt:</strong> {s.prompt}</div><EssayEditor essay={s} title={`${s.school} Supplemental`} isStudent={isStudent} /></div>)}
    </div>
  );
}

// ─── RESUME ───────────────────────────────────────────────────────────────────
function ResumeTab() {
  const [canvaUrl, setCanvaUrl] = useState("");
  const [inputUrl, setInputUrl] = useState("");
  const [editMode, setEditMode] = useState(true);
  const saveUrl = () => { if (inputUrl.trim()) { setCanvaUrl(inputUrl.trim()); setEditMode(false); } };
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div><H>Resume</H><div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#666", marginTop: -12 }}>Built on Canva — link it here so your counselor always has access to the latest version.</div></div>
        {canvaUrl && <div style={{ display: "flex", gap: 8 }}><a href={canvaUrl} target="_blank" rel="noreferrer" style={{ padding: "10px 18px", background: TEAL, color: "white", borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, textDecoration: "none" }}>Open in Canva ↗</a><button onClick={() => setEditMode(true)} style={{ padding: "10px 18px", background: "white", border: `2px solid ${TEAL}`, borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, color: TEAL, cursor: "pointer" }}>Update Link</button></div>}
      </div>
      {editMode && (
        <div style={{ padding: 20, background: PEACH, borderRadius: 14, border: `1px solid ${LIGHT_GOLD}`, marginBottom: 20 }}>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 600, color: BROWN, marginBottom: 8 }}>Paste your Canva share link</div>
          <div style={{ display: "flex", gap: 10 }}>
            <input value={inputUrl} onChange={e => setInputUrl(e.target.value)} placeholder="https://www.canva.com/design/..." style={{ flex: 1, padding: "10px 14px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} />
            <button onClick={saveUrl} style={{ padding: "10px 18px", background: TEAL, color: "white", border: "none", borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, cursor: "pointer" }}>Save</button>
          </div>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#999", marginTop: 8 }}>In Canva: Share → Copy link → Paste above. Set sharing to "Anyone with the link can view."</div>
        </div>
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 20 }}>
        <div style={{ borderRadius: 14, border: "2px solid #e8e0d0", background: "#f8f5f0", minHeight: 500, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ textAlign: "center", padding: 40 }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📄</div>
            <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 22, fontWeight: 700, color: DARK_TEAL, marginBottom: 8 }}>Resume Preview</div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#888", marginBottom: 20, lineHeight: 1.6 }}>Canva designs open directly in Canva.<br />{canvaUrl ? "Click the button above to view." : "Add your Canva link to get started."}</div>
            {canvaUrl && <a href={canvaUrl} target="_blank" rel="noreferrer" style={{ padding: "12px 24px", background: `linear-gradient(135deg,${TEAL},${DARK_TEAL})`, color: "white", borderRadius: 12, fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 14, textDecoration: "none" }}>Open Resume in Canva ↗</a>}
          </div>
        </div>
        <Card style={{ boxShadow: "none", border: `1px solid ${LIGHT_GOLD}`, background: PEACH }}>
          <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 18, fontWeight: 700, color: DARK_TEAL, marginBottom: 14 }}>Resume Checklist</div>
          {[["Contact info & professional email", true], ["Education with GPA", true], ["Activities in reverse-chron order", true], ["Quantified impact (numbers, $)", false], ["Awards & honors section", true], ["Skills / languages", false], ["Clean, one-page layout", true], ["Reviewed by Dr. Markii", false]].map(([item, done], i) => (
            <div key={i} style={{ display: "flex", gap: 10, alignItems: "center", padding: "8px 0", borderBottom: i < 7 ? "1px solid #f0e6d3" : "none" }}>
              <div style={{ width: 20, height: 20, borderRadius: 5, background: done ? GREEN : "white", border: `2px solid ${done ? GREEN : "#ccc"}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 11, color: "white" }}>{done ? "✓" : ""}</div>
              <span style={{ fontFamily: "'DM Sans'", fontSize: 13, color: done ? "#888" : "#333", textDecoration: done ? "line-through" : "none" }}>{item}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

// ─── COMMON APP ACTIVITIES ────────────────────────────────────────────────────
const CA_TYPES = ["Academic", "Art", "Athletics: Club", "Athletics: JV/Varsity", "Career-Oriented", "Community Service (Volunteer)", "Computer/Technology", "Cultural", "Dance", "Debate/Speech", "Environmental", "Family Responsibilities", "Foreign Language", "Journalism/Publication", "Junior R.O.T.C.", "LGBT", "Music: Instrumental", "Music: Vocal", "Other Club/Activity", "Religious", "Research", "Robotics", "School Spirit", "Science/Math", "Social Justice", "Student Govt./Politics", "Theater/Drama", "Work (Paid)", "Other"];

function CommonAppActivitiesTab() {
  const [activities, setActivities] = useState([
    { type: "Athletics: JV/Varsity", position: "Captain", org: "Varsity Tennis Team", desc: "Led 18-member team to state semifinals; organized 3 charity tournaments raising $4,200 for youth programs.", grades: { 9: false, 10: true, 11: true, 12: true, pg: false }, timing: "All Year", hoursPerWeek: "15", weeksPerYear: "36", current: true, collegeIntent: true },
    { type: "Community Service (Volunteer)", position: "Founder & CEO", org: "CodeForChange", desc: "Founded nonprofit teaching coding to underserved youth; 47 students served; partnered with 3 Miami schools.", grades: { 9: false, 10: false, 11: true, 12: true, pg: false }, timing: "All Year", hoursPerWeek: "10", weeksPerYear: "48", current: true, collegeIntent: true },
    { type: "Research", position: "Research Assistant", org: "University of Miami – Prof. Chen Lab", desc: "Assisted on ML algorithm for early disease detection; co-authored conference abstract.", grades: { 9: false, 10: false, 11: true, 12: false, pg: false }, timing: "School Break", hoursPerWeek: "8", weeksPerYear: "12", current: false, collegeIntent: false },
  ]);
  const [expanded, setExpanded] = useState(0);
  const upd = (i, f, v) => setActivities(p => p.map((a, j) => j === i ? { ...a, [f]: v } : a));
  const updG = (i, g, v) => setActivities(p => p.map((a, j) => j === i ? { ...a, grades: { ...a.grades, [g]: v } } : a));

  return (
    <div>
      <div style={{ padding: "14px 18px", background: `linear-gradient(135deg,${DARK_TEAL},${TEAL})`, borderRadius: 14, marginBottom: 20, color: "white", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div><div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 20, fontWeight: 700 }}>Common App Activities</div><div style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "rgba(255,255,255,.7)", marginTop: 2 }}>Up to 10 · 150 char descriptions · Mirroring Common App exactly</div></div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 28, fontWeight: 700, color: GOLD }}>{activities.length}<span style={{ fontSize: 16, color: "rgba(255,255,255,.6)" }}>/10</span></div>
      </div>
      {activities.map((act, i) => {
        const isOpen = expanded === i;
        const dLeft = 150 - act.desc.length;
        return (
          <div key={i} style={{ marginBottom: 12, borderRadius: 14, border: `2px solid ${isOpen ? TEAL : "#e8e0d0"}`, overflow: "hidden" }}>
            <div onClick={() => setExpanded(isOpen ? null : i)} style={{ padding: "14px 18px", background: isOpen ? PEACH : "white", cursor: "pointer", display: "flex", gap: 14, alignItems: "center" }}>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: isOpen ? TEAL : LIGHT_GOLD, color: isOpen ? "white" : BROWN, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 13, flexShrink: 0 }}>{i + 1}</div>
              <div style={{ flex: 1 }}><div style={{ fontFamily: "'DM Sans'", fontWeight: 700, color: DARK_TEAL, fontSize: 14 }}>{act.org || "New Activity"}</div><div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#888", marginTop: 2 }}>{act.type} · {act.position || "Position"}</div></div>
              <div style={{ fontSize: 18, color: TEAL, transition: "transform .2s", transform: isOpen ? "rotate(90deg)" : "none" }}>›</div>
            </div>
            {isOpen && (
              <div style={{ padding: 20, borderTop: "1px solid #e8e0d0" }}>
                <div style={{ marginBottom: 14 }}><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>ACTIVITY TYPE *</label><select value={act.type} onChange={e => upd(i, "type", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, background: "white", outline: "none" }}>{CA_TYPES.map(t => <option key={t}>{t}</option>)}</select></div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                  <div><div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><label style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN }}>POSITION/LEADERSHIP *</label><span style={{ fontFamily: "'DM Sans'", fontSize: 11, color: 50 - act.position.length < 5 ? RED : "#aaa" }}>{act.position.length}/50</span></div><input value={act.position} onChange={e => upd(i, "position", e.target.value.slice(0, 50))} placeholder="e.g. Captain, Founder" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} /></div>
                  <div><div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><label style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN }}>ORGANIZATION NAME *</label><span style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "#aaa" }}>{act.org.length}/100</span></div><input value={act.org} onChange={e => upd(i, "org", e.target.value.slice(0, 100))} placeholder="Full organization name" style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} /></div>
                </div>
                <div style={{ marginBottom: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><label style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN }}>DESCRIPTION * (what you accomplished + recognition)</label><span style={{ fontFamily: "'DM Sans'", fontSize: 11, color: dLeft < 10 ? RED : dLeft < 30 ? BROWN : "#aaa", flexShrink: 0, marginLeft: 8 }}>{act.desc.length}/150</span></div>
                  <textarea value={act.desc} onChange={e => upd(i, "desc", e.target.value.slice(0, 150))} rows={3} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: `1.5px solid ${dLeft < 10 ? "#f1948a" : "#ddd"}`, fontFamily: "'DM Sans'", fontSize: 14, resize: "none", outline: "none", lineHeight: 1.6 }} />
                  {dLeft < 30 && <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: dLeft < 10 ? RED : BROWN, marginTop: 4 }}>{dLeft} characters remaining — make every word count.</div>}
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                  <div><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 8 }}>GRADE LEVELS *</label><div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>{[["9", "9th"], ["10", "10th"], ["11", "11th"], ["12", "12th"], ["pg", "PG"]].map(([k, l]) => <label key={k} style={{ display: "flex", alignItems: "center", gap: 5, cursor: "pointer", fontFamily: "'DM Sans'", fontSize: 13 }}><input type="checkbox" checked={!!act.grades[k]} onChange={e => updG(i, k, e.target.checked)} style={{ accentColor: TEAL }} />{l}</label>)}</div></div>
                  <div><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 8 }}>TIMING *</label><div style={{ display: "flex", gap: 12 }}>{["School Year", "School Break", "All Year"].map(t => <label key={t} style={{ display: "flex", alignItems: "center", gap: 5, cursor: "pointer", fontFamily: "'DM Sans'", fontSize: 13 }}><input type="radio" checked={act.timing === t} onChange={() => upd(i, "timing", t)} style={{ accentColor: TEAL }} />{t.replace("School ", "")}</label>)}</div></div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12 }}>
                  <div><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>HRS/WEEK *</label><input type="number" value={act.hoursPerWeek} onChange={e => upd(i, "hoursPerWeek", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} /></div>
                  <div><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>WKS/YEAR *</label><input type="number" value={act.weeksPerYear} onChange={e => upd(i, "weeksPerYear", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} /></div>
                  <label style={{ display: "flex", alignItems: "flex-end", gap: 6, paddingBottom: 10, cursor: "pointer", fontFamily: "'DM Sans'", fontSize: 13 }}><input type="checkbox" checked={act.current} onChange={e => upd(i, "current", e.target.checked)} style={{ accentColor: TEAL }} />Currently participate</label>
                  <label style={{ display: "flex", alignItems: "flex-end", gap: 6, paddingBottom: 10, cursor: "pointer", fontFamily: "'DM Sans'", fontSize: 13 }}><input type="checkbox" checked={act.collegeIntent} onChange={e => upd(i, "collegeIntent", e.target.checked)} style={{ accentColor: TEAL }} />Intend to continue</label>
                </div>
              </div>
            )}
          </div>
        );
      })}
      {activities.length < 10 && <button onClick={() => { setActivities(p => [...p, { type: "Other Club/Activity", position: "", org: "", desc: "", grades: { 9: false, 10: false, 11: false, 12: false, pg: false }, timing: "School Year", hoursPerWeek: "", weeksPerYear: "", current: false, collegeIntent: false }]); setExpanded(activities.length); }} style={{ marginTop: 8, padding: "12px 24px", background: "white", border: `2px dashed ${TEAL}`, borderRadius: 12, fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL, cursor: "pointer", width: "100%", fontSize: 14 }}>+ Add Activity ({10 - activities.length} slots remaining)</button>}
    </div>
  );
}

// ─── UC ACTIVITIES ────────────────────────────────────────────────────────────
const UC_CATS = ["Extracurricular Activity", "Educational Preparation Program", "Award or Honor", "Volunteering/Community Service", "Work Experience", "Other Coursework", "Special Circumstances"];

function UCActivitiesTab() {
  const [activities, setActivities] = useState([
    { category: "Extracurricular Activity", name: "Varsity Tennis — Captain", yearsParticipated: "3", hoursPerWeek: "15", weeksPerYear: "36", desc: "Served as captain of varsity tennis team for two seasons, leading team to state semifinals. Organized three charity tournaments raising $4,200 for youth after-school programs. Mentored JV players on-court and in academic planning." },
    { category: "Extracurricular Activity", name: "CodeForChange — Founder", yearsParticipated: "2", hoursPerWeek: "10", weeksPerYear: "48", desc: "Founded nonprofit providing free coding workshops to underserved youth in Miami-Dade. Grew program to serve 47 students across 3 partner schools. Secured $12,000 Knight Foundation grant. Currently expanding curriculum to include AI and machine learning modules." },
    { category: "Award or Honor", name: "Congressional App Challenge Finalist", yearsParticipated: "1", hoursPerWeek: "", weeksPerYear: "", desc: "Selected as national finalist for app designed to connect elderly residents with volunteer services. One of fewer than 100 finalists nationwide from 6,000+ applicants." },
  ]);
  const [expanded, setExpanded] = useState(0);
  const upd = (i, f, v) => setActivities(p => p.map((a, j) => j === i ? { ...a, [f]: v } : a));

  return (
    <div>
      <div style={{ padding: "14px 18px", background: `linear-gradient(135deg,#003d4d,#1a6b7a)`, borderRadius: 14, marginBottom: 8, color: "white", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div><div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 20, fontWeight: 700 }}>UC Application Activities</div><div style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "rgba(255,255,255,.7)", marginTop: 2 }}>Up to 20 items · 350 characters · 7 categories</div></div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 28, fontWeight: 700, color: GOLD }}>{activities.length}<span style={{ fontSize: 16, color: "rgba(255,255,255,.6)" }}>/20</span></div>
      </div>
      <div style={{ padding: "12px 16px", background: "#e8f4fd", borderRadius: 10, marginBottom: 20, border: "1px solid #aed6f1", display: "flex", gap: 12, alignItems: "flex-start" }}>
        <span style={{ fontSize: 18 }}>ℹ️</span>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "#2471a3", lineHeight: 1.6 }}><strong>UC vs. Common App:</strong> 350 chars (vs. 150), 7 categories including Work Experience, up to 20 items. Use the extra space to add context and <em>why it matters to you</em>.</div>
      </div>
      {activities.map((act, i) => {
        const isOpen = expanded === i;
        const dLeft = 350 - act.desc.length;
        return (
          <div key={i} style={{ marginBottom: 12, borderRadius: 14, border: `2px solid ${isOpen ? "#1a6b7a" : "#e8e0d0"}`, overflow: "hidden" }}>
            <div onClick={() => setExpanded(isOpen ? null : i)} style={{ padding: "14px 18px", background: isOpen ? "#e8f4fd" : "white", cursor: "pointer", display: "flex", gap: 14, alignItems: "center" }}>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: isOpen ? "#1a6b7a" : LIGHT_GOLD, color: isOpen ? "white" : BROWN, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 13, flexShrink: 0 }}>{i + 1}</div>
              <div style={{ flex: 1 }}><div style={{ fontFamily: "'DM Sans'", fontWeight: 700, color: DARK_TEAL, fontSize: 14 }}>{act.name || "New Activity"}</div><div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#888", marginTop: 2 }}>{act.category}</div></div>
              <div style={{ fontSize: 18, color: "#1a6b7a", transition: "transform .2s", transform: isOpen ? "rotate(90deg)" : "none" }}>›</div>
            </div>
            {isOpen && (
              <div style={{ padding: 20, borderTop: "1px solid #e8e0d0" }}>
                <div style={{ marginBottom: 14 }}><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>CATEGORY *</label><select value={act.category} onChange={e => upd(i, "category", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, background: "white", outline: "none" }}>{UC_CATS.map(c => <option key={c}>{c}</option>)}</select></div>
                <div style={{ marginBottom: 14 }}><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>ACTIVITY / AWARD NAME *</label><input value={act.name} onChange={e => upd(i, "name", e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} /></div>
                {act.category !== "Award or Honor" && (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginBottom: 14 }}>
                    {[["YEARS PARTICIPATED", "yearsParticipated"], ["HOURS PER WEEK", "hoursPerWeek"], ["WEEKS PER YEAR", "weeksPerYear"]].map(([label, field]) => (
                      <div key={field}><label style={{ display: "block", fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN, marginBottom: 6 }}>{label}</label><input type="number" value={act[field]} onChange={e => upd(i, field, e.target.value)} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} /></div>
                    ))}
                  </div>
                )}
                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><label style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, color: BROWN }}>DESCRIPTION * <span style={{ fontWeight: 400, color: "#999" }}>(what, your role, impact, why it matters)</span></label><span style={{ fontFamily: "'DM Sans'", fontSize: 11, color: dLeft < 20 ? RED : dLeft < 60 ? BROWN : "#aaa", flexShrink: 0, marginLeft: 8 }}>{act.desc.length}/350</span></div>
                  <textarea value={act.desc} onChange={e => upd(i, "desc", e.target.value.slice(0, 350))} rows={5} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: `1.5px solid ${dLeft < 20 ? "#f1948a" : "#ddd"}`, fontFamily: "'DM Sans'", fontSize: 14, resize: "none", outline: "none", lineHeight: 1.6 }} />
                  <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#999", marginTop: 6 }}>You have {dLeft} more characters — use them. Tell us the <em>why</em>, not just the what.</div>
                </div>
              </div>
            )}
          </div>
        );
      })}
      {activities.length < 20 && <button onClick={() => { setActivities(p => [...p, { category: "Extracurricular Activity", name: "", yearsParticipated: "", hoursPerWeek: "", weeksPerYear: "", desc: "" }]); setExpanded(activities.length); }} style={{ marginTop: 8, padding: "12px 24px", background: "white", border: "2px dashed #1a6b7a", borderRadius: 12, fontFamily: "'DM Sans'", fontWeight: 600, color: "#1a6b7a", cursor: "pointer", width: "100%", fontSize: 14 }}>+ Add Activity/Award/Experience ({20 - activities.length} slots remaining)</button>}
    </div>
  );
}

// ─── CONTACT LOG ──────────────────────────────────────────────────────────────
function ContactLogTab({ student, isStudent }) {
  const [logs, setLogs] = useState(student.contactLog);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ date: "", contact: "Dr. Markii", type: "Video Call", notes: "" });
  const addLog = () => {
    if (!form.date || !form.notes) return;
    setLogs(p => [{ ...form }, ...p]);
    setForm({ date: "", contact: "Dr. Markii", type: "Video Call", notes: "" });
    setShowForm(false);
  };
  return (
    <div>
      {!isStudent && (
        <div style={{ marginBottom: 20 }}>
          {!showForm
            ? <button onClick={() => setShowForm(true)} style={{ padding: "10px 20px", background: TEAL, color: "white", border: "none", borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, cursor: "pointer" }}>+ Log New Contact</button>
            : <div style={{ padding: 20, background: PEACH, borderRadius: 14, border: `1px solid ${LIGHT_GOLD}`, marginBottom: 16 }}>
                <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 18, fontWeight: 700, color: DARK_TEAL, marginBottom: 16 }}>Log a Contact</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 12 }}>
                  {[["DATE", "date", "date"], ["CONTACTED BY", "contact", "text"], ["TYPE", "type", "text"]].map(([label, field, type]) => (
                    <div key={field}>
                      <div style={{ fontFamily: "'DM Sans'", fontSize: 11, fontWeight: 600, color: BROWN, marginBottom: 6 }}>{label}</div>
                      {field === "contact"
                        ? <select value={form.contact} onChange={e => setForm(p => ({ ...p, contact: e.target.value }))} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, background: "white", outline: "none" }}>{["Dr. Markii", "Jennifer", "Dr. Pauline", "Both"].map(o => <option key={o}>{o}</option>)}</select>
                        : field === "type"
                          ? <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, background: "white", outline: "none" }}>{["Video Call", "Phone Call", "Email", "In-Person", "Text/WhatsApp"].map(o => <option key={o}>{o}</option>)}</select>
                          : <input type={type} value={form[field]} onChange={e => setForm(p => ({ ...p, [field]: e.target.value }))} style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, outline: "none" }} />
                      }
                    </div>
                  ))}
                </div>
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontFamily: "'DM Sans'", fontSize: 11, fontWeight: 600, color: BROWN, marginBottom: 6 }}>SESSION NOTES & SUMMARY</div>
                  <textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={4} placeholder="What was discussed? What was assigned? Any key decisions?" style={{ width: "100%", padding: "12px 14px", borderRadius: 10, border: "1px solid #ddd", fontFamily: "'DM Sans'", fontSize: 14, resize: "none", outline: "none", lineHeight: 1.6 }} />
                </div>
                <div style={{ display: "flex", gap: 8 }}><button onClick={addLog} style={{ padding: "10px 20px", background: TEAL, color: "white", border: "none", borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, cursor: "pointer" }}>Save Log</button><button onClick={() => setShowForm(false)} style={{ padding: "10px 20px", background: "white", border: "1px solid #ddd", borderRadius: 10, fontFamily: "'DM Sans'", cursor: "pointer" }}>Cancel</button></div>
              </div>
          }
        </div>
      )}
      {logs.map((c, i) => (
        <div key={i} style={{ display: "flex", gap: 16, marginBottom: 16, padding: 18, background: i % 2 === 0 ? PEACH : "white", borderRadius: 14, border: "1px solid #f0e6d3" }}>
          <div style={{ flexShrink: 0, textAlign: "center", minWidth: 64 }}>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "#bbb" }}>DATE</div>
            <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 16, fontWeight: 700, color: TEAL }}>{c.date}</div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 10, color: "#888", marginTop: 4, background: LIGHT_GOLD, padding: "2px 8px", borderRadius: 10, whiteSpace: "nowrap" }}>{c.type}</div>
          </div>
          <div style={{ borderLeft: `3px solid ${GOLD}`, paddingLeft: 16, flex: 1 }}>
            <div style={{ fontFamily: "'DM Sans'", fontWeight: 700, color: BROWN, marginBottom: 6 }}>{c.contact}</div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#555", lineHeight: 1.6 }}>{c.notes}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── SCHOLARSHIPS ─────────────────────────────────────────────────────────────
function ScholarshipsTab({ student }) {
  const total = student.scholarships.reduce((a, s) => { const m = s.amount.match(/\$[\d,]+/); return m ? a + parseInt(m[0].replace(/[$,]/g, "")) : a; }, 0);
  return (
    <div>
      <div style={{ background: `linear-gradient(135deg,${DARK_TEAL},${TEAL})`, borderRadius: 14, padding: 20, marginBottom: 20, color: "white" }}>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 11, letterSpacing: 2, color: GOLD, marginBottom: 4 }}>POTENTIAL SCHOLARSHIP VALUE</div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 40, fontWeight: 700, color: GOLD }}>${total.toLocaleString()}+</div>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "rgba(255,255,255,.7)" }}>Apply to all — every dollar matters. Beat the odds.</div>
      </div>
      {student.scholarships.map((s, i) => (
        <div key={i} style={{ marginBottom: 12, padding: 18, borderRadius: 14, background: i % 2 === 0 ? PEACH : "white", border: "1px solid #f0e6d3" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><div style={{ fontFamily: "'DM Sans'", fontWeight: 700, color: DARK_TEAL, fontSize: 15 }}>{s.name}</div><div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 20, fontWeight: 700, color: GOLD }}>{s.amount}</div></div>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "#666", marginBottom: 8 }}>{s.requirements}</div>
          <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "#888" }}>Due: {s.deadline}</span><Badge>{s.status}</Badge></div>
        </div>
      ))}
    </div>
  );
}

// ─── NARRATIVE TAB ────────────────────────────────────────────────────────────
function NarrativeTab({ student }) {
  return (
    <div>
      <div style={{ background: `linear-gradient(135deg,${DARK_TEAL},${TEAL})`, borderRadius: 16, padding: 24, marginBottom: 20, color: "white" }}>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 11, letterSpacing: 3, color: GOLD, marginBottom: 8 }}>YOUR NARRATIVE IDENTITY</div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 26, fontWeight: 700, marginBottom: 8 }}>"{student.narrativeTheme}"</div>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "rgba(255,255,255,.75)", marginBottom: 16 }}>{student.spike}</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>{student.coreValues.map(v => <div key={v} style={{ padding: "6px 16px", background: "rgba(201,162,39,.2)", border: `1px solid ${GOLD}`, borderRadius: 20, fontFamily: "'DM Sans'", fontWeight: 600, fontSize: 13, color: GOLD }}>{v}</div>)}</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <Card style={{ background: PEACH, boxShadow: "none", border: `1px solid ${LIGHT_GOLD}` }}>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 11, letterSpacing: 2, color: BROWN, marginBottom: 6 }}>DREAM SCHOOL</div>
          <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 22, fontWeight: 700, color: DARK_TEAL, marginBottom: 4 }}>{student.dreamSchool}</div>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "#666" }}>Major: <strong>{student.targetMajor}</strong></div>
        </Card>
        <Card>
          <div style={{ fontFamily: "'DM Sans'", fontSize: 11, letterSpacing: 2, color: TEAL, marginBottom: 10 }}>HOW AN AO SEES YOU NOW</div>
          {[["Academic Story", "Strong ✓", GREEN], ["Spike", "Clear ✓", GREEN], ["Narrative Thread", "Emerging ◐", BROWN], ["Essay Voice", "Draft Stage ◐", BROWN]].map(([l, v, c]) => <div key={l} style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}><span style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "#666" }}>{l}</span><span style={{ fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 700, color: c }}>{v}</span></div>)}
        </Card>
      </div>
    </div>
  );
}

// ─── ROADMAP ──────────────────────────────────────────────────────────────────
function RoadmapTab({ student }) {
  const done = student.milestones.filter(m => m.done).length;
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><span style={{ fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL }}>{done} of {student.milestones.length} milestones</span><span style={{ fontFamily: "'DM Sans'", fontSize: 13, color: "#888" }}>{Math.round(done / student.milestones.length * 100)}%</span></div>
      <div style={{ marginBottom: 24 }}><PBar value={done / student.milestones.length * 100} height={10} /></div>
      <div style={{ position: "relative", paddingLeft: 44 }}>
        <div style={{ position: "absolute", left: 20, top: 0, bottom: 0, width: 2, background: `linear-gradient(${TEAL},${GOLD})`, borderRadius: 2 }} />
        {student.milestones.map((m, i) => (
          <div key={i} style={{ position: "relative", marginBottom: 20 }}>
            <div style={{ position: "absolute", left: -34, top: 2, width: 28, height: 28, borderRadius: "50%", background: m.done ? GREEN : "white", border: `2px solid ${m.done ? GREEN : "#ccc"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, color: m.done ? "white" : "#ccc" }}>{m.done ? "✓" : "○"}</div>
            <div style={{ padding: "14px 18px", borderRadius: 12, background: m.done ? "#e9f7ef" : "white", border: `1px solid ${m.done ? "#a9dfbf" : "#e8e0d0"}` }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}><div style={{ fontFamily: "'DM Sans'", fontWeight: 600, color: m.done ? GREEN : DARK_TEAL, fontSize: 14 }}>{m.label}</div><div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#888" }}>{m.date}</div></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── STUDENT PORTAL ───────────────────────────────────────────────────────────
function StudentPortal({ student, isStudent }) {
  const [tab, setTab] = useState("narrative");
  const tabs = [
    { id: "narrative",    label: "My Story",     icon: "✦" },
    { id: "lifemap",      label: "Life Map",      icon: "🗺" },
    { id: "visionboard",  label: "Vision Board",  icon: "🎨" },
    { id: "beatodds",     label: "Beat the Odds", icon: "⚡" },
    { id: "roadmap",      label: "Roadmap",       icon: "📍" },
    { id: "checklist",    label: "Checklist",     icon: "✓" },
    { id: "homework",     label: "Homework",      icon: "📋" },
    { id: "colleges",     label: "Colleges",      icon: "🏛" },
    { id: "essays",       label: "Essays",        icon: "✍️" },
    { id: "caactivities", label: "Common App",    icon: "📝" },
    { id: "ucactivities", label: "UC Activities", icon: "🎓" },
    { id: "resume",       label: "Resume",        icon: "📄" },
    { id: "scholarships", label: "Scholarships",  icon: "💰" },
    { id: "contact",      label: "Contact Log",   icon: "📞" },
  ];
  return (
    <div>
      <div style={{ background: `linear-gradient(135deg,${DARK_TEAL},${TEAL})`, borderRadius: 20, padding: 32, marginBottom: 24, position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -60, right: -60, width: 240, height: 240, borderRadius: "50%", background: "rgba(201,162,39,.1)" }} />
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 12, color: GOLD, letterSpacing: 3, marginBottom: 6 }}>DREAM EDUCATION CONSULTING</div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 32, fontWeight: 700, color: "white", marginBottom: 4 }}>{student.name}</div>
        <div style={{ fontFamily: "'DM Sans'", fontSize: 14, color: "rgba(255,255,255,.65)", marginBottom: 20 }}>Dream: <strong style={{ color: GOLD }}>{student.dreamSchool}</strong> · {student.grade} · GPA {student.gpa} · SAT {student.sat}</div>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          {[{ l: "Progress", v: `${student.progress}%` }, { l: "Colleges", v: student.collegeList.length }, { l: "Tasks Pending", v: student.homework.filter(h => h.status !== "Complete").length }].map(s => (
            <div key={s.l} style={{ background: "rgba(255,255,255,.12)", backdropFilter: "blur(8px)", borderRadius: 12, padding: "12px 20px", textAlign: "center" }}>
              <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 28, fontWeight: 700, color: GOLD }}>{s.v}</div>
              <div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "rgba(255,255,255,.6)" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>
      <TabBar tabs={tabs} active={tab} onSelect={setTab} />
      <Card>
        {tab === "narrative"    && <NarrativeTab student={student} />}
        {tab === "lifemap"      && <LifeMapTab />}
        {tab === "visionboard"  && <VisionBoardTab />}
        {tab === "beatodds"     && <BeatTheOddsTab student={student} />}
        {tab === "roadmap"      && <RoadmapTab student={student} />}
        {tab === "checklist"    && <ChecklistTab student={student} />}
        {tab === "homework"     && <HomeworkTab student={student} />}
        {tab === "colleges"     && <CollegeListTab student={student} />}
        {tab === "essays"       && <EssaysTab student={student} isStudent={isStudent} />}
        {tab === "caactivities" && <CommonAppActivitiesTab />}
        {tab === "ucactivities" && <UCActivitiesTab />}
        {tab === "resume"       && <ResumeTab />}
        {tab === "scholarships" && <ScholarshipsTab student={student} />}
        {tab === "contact"      && <ContactLogTab student={student} isStudent={isStudent} />}
      </Card>
    </div>
  );
}

// ─── COUNSELOR PORTAL ─────────────────────────────────────────────────────────
function CounselorPortal({ user }) {
  const [sel, setSel] = useState(null);
  if (sel) return <div><button onClick={() => setSel(null)} style={{ marginBottom: 16, padding: "8px 16px", background: "white", border: `2px solid ${TEAL}`, borderRadius: 10, fontFamily: "'DM Sans'", fontWeight: 600, color: TEAL, cursor: "pointer" }}>← All Students</button><StudentPortal student={sel} isStudent={false} /></div>;
  return (
    <div>
      <div style={{ background: `linear-gradient(135deg,${DARK_TEAL},${TEAL})`, borderRadius: 20, padding: 28, marginBottom: 24 }}>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 12, color: GOLD, letterSpacing: 3, marginBottom: 6 }}>COUNSELOR COMMAND CENTER</div>
        <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 32, fontWeight: 700, color: "white", marginBottom: 16 }}>{user.name}'s Dashboard</div>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          {[{ l: "Active Students", v: STUDENTS.length }, { l: "Urgent Items", v: STUDENTS.reduce((a, s) => a + s.urgentItems, 0) }, { l: "Essays In Review", v: 1 }, { l: "Avg Progress", v: `${Math.round(STUDENTS.reduce((a, s) => a + s.progress, 0) / STUDENTS.length)}%` }].map(s => (
            <div key={s.l} style={{ background: "rgba(255,255,255,.12)", borderRadius: 12, padding: "12px 20px", textAlign: "center" }}>
              <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 28, fontWeight: 700, color: GOLD }}>{s.v}</div>
              <div style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "rgba(255,255,255,.7)" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>
      <H>Your Students</H>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {STUDENTS.map(s => (
          <Card key={s.id} style={{ cursor: "pointer" }} onClick={() => setSel(s)}>
            <div style={{ display: "flex", gap: 14, marginBottom: 14 }}>
              <div style={{ width: 52, height: 52, borderRadius: 16, background: `linear-gradient(135deg,${TEAL},${GOLD})`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans'", fontWeight: 700, color: "white", fontSize: 16, flexShrink: 0 }}>{s.avatar}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 20, fontWeight: 700, color: DARK_TEAL }}>{s.name}</div>
                <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#888" }}>{s.grade} · {s.narrativeTheme}</div>
              </div>
              {s.urgentItems > 0 && <div style={{ background: "#fde8e8", color: RED, borderRadius: 10, padding: "4px 10px", fontFamily: "'DM Sans'", fontWeight: 700, fontSize: 12, alignSelf: "flex-start" }}>{s.urgentItems} urgent</div>}
            </div>
            <div style={{ marginBottom: 10, padding: "8px 12px", background: PEACH, borderRadius: 10 }}>
              <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: BROWN, fontWeight: 600 }}>🎯 {s.dreamSchool}</div>
              <div style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#666", marginTop: 2 }}>✦ {s.spike}</div>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><span style={{ fontFamily: "'DM Sans'", fontSize: 12, color: "#888" }}>Progress</span><span style={{ fontFamily: "'DM Sans'", fontWeight: 700, color: TEAL, fontSize: 12 }}>{s.progress}%</span></div>
            <PBar value={s.progress} />
            <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
              {[`GPA ${s.gpa}`, `SAT ${s.sat}`, `${s.collegeList.length} colleges`, `${s.homework.filter(h => h.status !== "Complete").length} tasks`].map(t => <span key={t} style={{ fontFamily: "'DM Sans'", fontSize: 11, color: "#666", background: PEACH, padding: "3px 8px", borderRadius: 6 }}>{t}</span>)}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const student = user?.role === "student" ? STUDENTS.find(s => s.id === user.studentId) : null;

  if (!user) return <LoginScreen onLogin={setUser} />;

  return (
    <div style={{ minHeight: "100vh", background: CREAM }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap');*{box-sizing:border-box;margin:0;padding:0;}button{transition:opacity .15s;}button:hover{opacity:.88;}textarea,input{box-sizing:border-box;}`}</style>
      <div style={{ background: DARK_TEAL, padding: "14px 32px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100, boxShadow: "0 2px 20px rgba(0,0,0,.3)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: GOLD, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🦉</div>
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond'", fontSize: 18, fontWeight: 700, color: "white" }}>Dream Education</div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 9, color: GOLD, letterSpacing: 3 }}>CONSULTING</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: "50%", background: `linear-gradient(135deg,${TEAL},${GOLD})`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans'", fontWeight: 700, color: "white", fontSize: 13 }}>
            {(user.role === "student" ? student?.name : user.name || "").split(" ").map(w => w[0]).join("").slice(0, 2)}
          </div>
          <div>
            <div style={{ fontFamily: "'DM Sans'", fontWeight: 600, color: "white", fontSize: 13 }}>{user.role === "student" ? student?.name : user.name}</div>
            <div style={{ fontFamily: "'DM Sans'", fontSize: 10, color: "rgba(255,255,255,.55)" }}>{user.role === "student" ? "Student Portal" : "Counselor"}</div>
          </div>
          <button onClick={() => setUser(null)} style={{ marginLeft: 12, padding: "6px 14px", background: "rgba(255,255,255,.12)", border: "1px solid rgba(255,255,255,.2)", borderRadius: 8, fontFamily: "'DM Sans'", fontSize: 12, color: "rgba(255,255,255,.7)", cursor: "pointer" }}>Sign out</button>
        </div>
      </div>
      <div style={{ maxWidth: 1160, margin: "0 auto", padding: "28px 24px" }}>
        {user.role === "counselor" ? <CounselorPortal user={user} /> : <StudentPortal student={student} isStudent={true} />}
      </div>
    </div>
  );
}
